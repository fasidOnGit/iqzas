if [[ -z "${TC_ROOT}" ]]; then
echo "Please set TC_ROOT with Teamcenter root directory path."
exit
fi

if [[ -z "${TC_DATA}" ]]; then
echo "Please set TC_DATA with tcdata path"
exit
fi

if [[ -z "${1}" ]]; then
echo "Please give Teamcenter Version value  like EzWorkflow.bat 11. Options are  : 10 or 11."
exit
fi

curr_dir=$PWD

if [ $1 = "10" ]; then
   cp -r ./TC10/lib/. $TC_ROOT/lib
fi

if [ $1 = "11" ]; then
  cp -r ./TC11/lib/. $TC_ROOT/lib
fi

echo "Starting Copying Configuration To TC_Data"
cp -r ./soa/. $TC_DATA/soa/
echo "Finished Copying Configuration To TC_Data"

echo "////////////////////////////////////////////"
echo "EzWorkflow Teamcenter installation completed."
echo "NOTE : Please restart your Pool Manager."
echo "////////////////////////////////////////////"
